def new_list():
    new_list = {
        "elements": [],
        "size": 0,
    }
    return new_list


def get_element(my_list, pos):
    if pos < 0 or pos >= my_list["size"]:
        return None
    return my_list["elements"][pos]


def is_present(my_list, element, cmp_function):
    for pos in range(0, my_list["size"]):
        info = my_list["elements"][pos]

        if cmp_function(element, info) == 0:
            return pos

    return -1


def add_first(my_list, value):
    my_list["elements"].insert(0, value)
    my_list["size"] += 1
    return my_list


def add_last(my_list, value):
    my_list["elements"].append(value)
    my_list["size"] += 1
    return my_list


def size(my_list):
    return my_list["size"]


def first_element(my_list):
    if my_list["size"] == 0:
        return None
    return my_list["elements"][0]


def last_element(my_list):
    if my_list["size"] == 0:
        return None
    return my_list["elements"][-1]


def is_empty(my_list):
    return my_list["size"] == 0


def remove_last(my_list):
    if not is_empty(my_list):
        my_list["elements"].pop()
        my_list["size"] -= 1
    return my_list["size"]


def delete_element(my_list, pos):
    if 0 <= pos < my_list["size"]:
        del my_list["elements"][pos]
        my_list["size"] -= 1
    return my_list


def remove_first(my_list):
    if not is_empty(my_list):
        my_list["elements"].pop(0)
        my_list["size"] -= 1
    return my_list["size"]


def insert_element(my_list, element, pos):
    if 0 <= pos <= my_list["size"]:
        my_list["elements"].insert(pos, element)
        my_list["size"] += 1
    return my_list


def change_info(my_list, pos, new_element):
    if 0 <= pos < my_list["size"]:
        my_list["elements"][pos] = new_element
    return my_list


def exchange(my_list, pos1, pos2):
    if (0 <= pos1 < my_list["size"] and
            0 <= pos2 < my_list["size"]):

        my_list["elements"][pos1], my_list["elements"][pos2] = (
            my_list["elements"][pos2],
            my_list["elements"][pos1]
        )
    return my_list


def sub_list(my_list, start_pos, num_elements):
    if (start_pos < 0 or
            start_pos >= my_list["size"] or
            num_elements < 0):
        return None

    end_index = start_pos + num_elements

    sublist = {
        "elements": my_list["elements"][start_pos:end_index],
        "size": len(my_list["elements"][start_pos:end_index])
    }
    return sublist


def default_sort_criteria(a, b):
    return a < b


def selection_sort(my_list, sort_criterio):

    for f in range(0, my_list["size"] - 1):
        menor = f
        for i in range(f + 1, my_list["size"]):
            if sort_criterio(get_element(my_list, i), get_element(my_list, menor)):
                menor = i
        if menor != f:
            exchange(my_list, f, menor)

    return my_list


def insertion_sort(my_list, sort_criterio):
    for i in range(1, my_list["size"]):
        j = i
        while j > 0 and sort_criterio(get_element(my_list, j), get_element(my_list, j - 1)):
            exchange(my_list, j, j - 1)
            j -= 1
    return my_list


def shell_sort_aux(my_list, sort_criterio, h):
    for i in range(h, my_list["size"]):
        j = i
        while j >= h and sort_criterio(get_element(my_list, j), get_element(my_list, j - h)):
            exchange(my_list, j, j - h)
            j -= h
    return my_list


def shell_sort(my_list, sort_criterio):
    h = my_list["size"] // 2
    while h >= 1:
        shell_sort_aux(my_list, sort_criterio, h)
        h = h // 2
    return my_list


def merge(low, high, sort_criterio):
    resp = new_list()
    i = 0
    j = 0

    while i < low["size"] and j < high["size"]:
        elem_low = get_element(low, i)
        elem_high = get_element(high, j)

        if sort_criterio(elem_high, elem_low):
            add_last(resp, elem_high)
            j += 1
        else:
            add_last(resp, elem_low)
            i += 1
    while i < low["size"]:
        add_last(resp, get_element(low, i))
        i += 1

    while j < high["size"]:
        add_last(resp, get_element(high, j))
        j += 1
    return resp


def merge_sort(my_list, sort_criterio):
    #caso base
    if my_list["size"] <= 1:
        return my_list

    mid = size(my_list) // 2
    low = sub_list(my_list, 0, mid)
    high = sub_list(my_list, mid, my_list["size"] - mid)

    low = merge_sort(low, sort_criterio)
    high = merge_sort(high, sort_criterio)

    merged = merge(low, high, sort_criterio)

    my_list["elements"] = merged["elements"]
    my_list["size"] = merged["size"]

    return my_list


def particion(my_list, low, high, sort_criterio):
    pivot = get_element(my_list, high)
    i = low - 1

    for j in range(low, high):
        elem = get_element(my_list, j)
        if not sort_criterio(pivot, elem):
            i += 1
            exchange(my_list, i, j)

    exchange(my_list, i + 1, high)
    return i + 1


def quick_sort_aux(my_list, low, high, sort_criterio):
    if low < high:
        pos_pivot = particion(my_list, low, high, sort_criterio)
        quick_sort_aux(my_list, low, pos_pivot - 1, sort_criterio)
        quick_sort_aux(my_list, pos_pivot + 1, high, sort_criterio)


def quick_sort(my_list, sort_criterio):
    quick_sort_aux(my_list, 0, my_list["size"] - 1, sort_criterio)
    return my_list