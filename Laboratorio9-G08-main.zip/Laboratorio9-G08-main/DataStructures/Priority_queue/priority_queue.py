import pq_entry as pq
import List.array_list as lt
import math as m

def priority(my_heap, parent, child):
    return my_heap["cmp_function"](parent, child)
#MAX
def default_compare_higher_value(father_node, child_node):
    if pq.get_priority(father_node) >= pq.get_priority(child_node):
        return True
    return False
#MIN
def default_compare_lower_value(father_node, child_node):
    if pq.get_priority(father_node) <= pq.get_priority(child_node):
        return True
    return False

def new_heap(is_min_pq=True):
    if is_min_pq:
        compare= default_compare_lower_value
    else:
        compare= default_compare_higher_value
    heap={
        "elements":lt.new_list(),
        "size":0,
        "cmp_function":compare
    }
    return heap
def size(my_heap):
    return my_heap["size"]


def is_empty(my_heap):
    return my_heap["size"] == 0

def swim(my_heap, pos):
   if pos==1:
    return my_heap 
   heapi=my_heap["element"]
   nodo=lt.get_element(heapi,pos)
   padre=lt.get_element(heapi,m.floor(pos//2))
   if padre["priority"]<nodo["priority"]:
       tempo=nodo
       nodo=padre
       padre=nodo
       swim(my_heap,m.floor(pos//2))
   else:
       return my_heap
      
    
def insert(my_heap, value, key):
    entry = pq.new_entry(key, value)
    lt.add_last(my_heap["elements"], entry)
    
    swim(my_heap, my_heap["size"])
    
    return my_heap   
       
